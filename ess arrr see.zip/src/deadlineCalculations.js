

const daysOfWeek = ['', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

function calculateDeadline(county, courtDeadline) {

    if(!courtDeadline)
    {
        return undefined;
    }

    const proposedPublicationDate = courtDeadline;
    while(!daysOfWeek[proposedPublicationDate.isoWeekday()] in county.publicationDays)
    {
        proposedPublicationDate.subtract(1,'days');
    }

    const publicationDate = proposedPublicationDate;
    console.log(publicationDate);
    const pubDayName = daysOfWeek[publicationDate.isoWeekday()];
    console.log(pubDayName);
    const publicationDetails = county.publicationDays[pubDayName];
    console.log(publicationDetails);
    const submissionDate = publicationDate.subtract(publicationDetails.daysPrior,'days');

    return {submissionDate, submissionTime:publicationDetails.time};

}

export default calculateDeadline;